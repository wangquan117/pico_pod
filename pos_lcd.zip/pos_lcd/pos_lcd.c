/**
 * Copyright (c) 2020 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "hardware/sync.h"
#include "hardware/spi.h"

#define GPIO_UP_PIN 22
#define GPIO_DOWN_PIN 24
#define GPIO_LEFT_PIN 25
#define GPIO_RIGHT_PIN 23
#define GPIO_A_PIN 26
#define GPIO_B_PIN 6
#define GPIO_START_PIN 21
#define GPIO_SELECT_PIN 20

// SD_UI_PATCH: These LCD pins are inferred from the schematic currently
// provided by the user. If the panel responds with backlight only and no
// pixels, verify these nets first before changing the command table.
#define LCD_SPI_PORT spi1
#define LCD_PIN_RST 1
#define LCD_PIN_DC 8
#define LCD_PIN_CS 9
#define LCD_PIN_SCK 10
#define LCD_PIN_MOSI 11
#define LCD_PIN_TE 14
#define LCD_PIN_BL 15


//43.2W /0.18 = 240
#define LCD_WIDTH 240
//57.6H / 0.18 = 320
#define LCD_HEIGHT 320
//LCD SPI 通信时钟 40 MHz，从芯片手册时序上看，写 SPI 不应超过约 62.5 MHz，f_max = 1 / 16 ns = 62.5 MHz
#define LCD_SPI_BAUDRATE 40000000u
//延时120ms，防止按键抖动
#define BUTTON_DEBOUNCE_MS 120u

#define ST7789_CMD_SWRESET 0x01
#define ST7789_CMD_SLPOUT  0x11
#define ST7789_CMD_NORON   0x13
#define ST7789_CMD_INVOFF  0x20
#define ST7789_CMD_INVON   0x21
#define ST7789_CMD_DISPON  0x29
#define ST7789_CMD_CASET   0x2A
#define ST7789_CMD_RASET   0x2B
#define ST7789_CMD_RAMWR   0x2C
#define ST7789_CMD_MADCTL  0x36
#define ST7789_CMD_COLMOD  0x3A

typedef struct {
    uint gpio;
    const char *name;
} button_config_t;

typedef struct {
    uint16_t rgb565;
    const char *name;
} color_config_t;

// SD_UI_PATCH: Keep button mapping in one table so callback output and
// initialization always stay aligned.
static const button_config_t g_button_table[] = {
    {GPIO_UP_PIN, "UP"},
    {GPIO_DOWN_PIN, "DOWN"},
    {GPIO_LEFT_PIN, "LEFT"},
    {GPIO_RIGHT_PIN, "RIGHT"},
    {GPIO_A_PIN, "A"},
    {GPIO_B_PIN, "B"},
    {GPIO_START_PIN, "START"},
    {GPIO_SELECT_PIN, "SELECT"},
};

// SD_UI_PATCH: Pure colors make first-light validation easier because any
// orientation or byte-order issue is still immediately visible to the eye.
static const color_config_t g_color_table[] = {
    {0xF800, "RED"},
    {0x07E0, "GREEN"},
    {0x001F, "BLUE"},
    {0xFFE0, "YELLOW"},
    {0xF81F, "MAGENTA"},
    {0x07FF, "CYAN"},
    {0xFFFF, "WHITE"},
    {0x0000, "BLACK"},
};

static volatile bool g_color_change_requested = false;
static volatile uint32_t g_last_button_press_ms = 0;
static size_t g_color_index = 0;

static const char *test_gpio_name_from_pin(uint gpio)
{
    for (size_t i = 0; i < sizeof(g_button_table) / sizeof(g_button_table[0]); ++i) {
        if (g_button_table[i].gpio == gpio) {
            return g_button_table[i].name;
        }
    }

    return "UNKNOWN";
}

static void test_gpio_init_one_input(uint gpio)
{
    gpio_init(gpio);
    gpio_set_dir(gpio, GPIO_IN);
    gpio_pull_up(gpio);
}

static inline void lcd_select(void)
{
    gpio_put(LCD_PIN_CS, 0);
}

static inline void lcd_deselect(void)
{
    gpio_put(LCD_PIN_CS, 1);
}

static void lcd_write_bytes(const uint8_t *data, size_t length)
{
    if (length == 0) {
        return;
    }

    spi_write_blocking(LCD_SPI_PORT, data, length);
}

static void lcd_write_command(uint8_t command)
{
    gpio_put(LCD_PIN_DC, 0);
    lcd_select();
    lcd_write_bytes(&command, 1);
    lcd_deselect();
}

static void lcd_write_data(const uint8_t *data, size_t length)
{
    gpio_put(LCD_PIN_DC, 1);
    lcd_select();
    lcd_write_bytes(data, length);
    lcd_deselect();
}

static void lcd_write_command_with_data(uint8_t command, const uint8_t *data, size_t length)
{
    lcd_write_command(command);
    lcd_write_data(data, length);
}

static void lcd_hard_reset(void)
{
    // SD_UI_PATCH: The schematic shows a pull-down on LCD_RST, so firmware
    // must actively drive the line high to release the panel from reset.
    gpio_put(LCD_PIN_RST, 0);
    sleep_ms(30);
    gpio_put(LCD_PIN_RST, 1);
    sleep_ms(120);
}

//设置显示区域
static void lcd_set_address_window(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1)
{
    uint8_t buffer[4];

    buffer[0] = (uint8_t)(x0 >> 8);     // 起始列高字节
    buffer[1] = (uint8_t)(x0 & 0xFF);   // 起始列低字节
    buffer[2] = (uint8_t)(x1 >> 8);     // 结束列高字节
    buffer[3] = (uint8_t)(x1 & 0xFF);   // 结束列低字节
    //设置列地址
    lcd_write_command_with_data(ST7789_CMD_CASET, buffer, sizeof(buffer));

    buffer[0] = (uint8_t)(y0 >> 8);     // 起始行高字节
    buffer[1] = (uint8_t)(y0 & 0xFF);   // 起始行低字节
    buffer[2] = (uint8_t)(y1 >> 8);     // 结束行高字节
    buffer[3] = (uint8_t)(y1 & 0xFF);   // 结束行低字节
    //设置行地址
    lcd_write_command_with_data(ST7789_CMD_RASET, buffer, sizeof(buffer));
    //写内存
    lcd_write_command(ST7789_CMD_RAMWR);
}

//用指定的 RGB565 颜色填充整个屏幕
static void lcd_fill_color(uint16_t rgb565)
{
    //一次只准备并发送 64 个像素
    enum { PIXELS_PER_CHUNK = 64 };
    //每个像素 2 字节
    uint8_t chunk[PIXELS_PER_CHUNK * 2];
    //高颜色字节和低颜色字节
    const uint8_t msb = (uint8_t)(rgb565 >> 8);
    const uint8_t lsb = (uint8_t)(rgb565 & 0xFF);
    //总像素数
    const size_t total_pixels = (size_t)LCD_WIDTH * (size_t)LCD_HEIGHT;
    size_t remaining_pixels = total_pixels;

    //把 chunk 缓冲区填满重复的 RGB565 颜色值。
    for (size_t i = 0; i < PIXELS_PER_CHUNK; ++i) {
        chunk[i * 2] = msb;
        chunk[i * 2 + 1] = lsb;
    }

    //设置整个屏幕的地址窗口
    lcd_set_address_window(0, 0, LCD_WIDTH - 1, LCD_HEIGHT - 1);
    gpio_put(LCD_PIN_DC, 1);
    //打开片选
    lcd_select();
    
    // 循环发送 chunk 直到所有像素都被填充
    while (remaining_pixels > 0) 
    {
        const size_t pixels_this_round = remaining_pixels > PIXELS_PER_CHUNK ? PIXELS_PER_CHUNK : remaining_pixels;
        lcd_write_bytes(chunk, pixels_this_round * 2);
        remaining_pixels -= pixels_this_round;
    }
    // 关闭片选
    lcd_deselect();
}

static void lcd_init_pins(void)
{
    //先拉低，是为了让面板上电初期保持在复位态，避免乱跳
    gpio_init(LCD_PIN_RST);
    gpio_set_dir(LCD_PIN_RST, GPIO_OUT);
    gpio_put(LCD_PIN_RST, 0);

    //0 是命令1 是数据。默认给 1 只是一个相对安全的空闲态，真正发命令前代码里会再切成 0
    gpio_init(LCD_PIN_DC);
    gpio_set_dir(LCD_PIN_DC, GPIO_OUT);
    gpio_put(LCD_PIN_DC, 1);

    //片选拉高，空闲态
    gpio_init(LCD_PIN_CS);
    gpio_set_dir(LCD_PIN_CS, GPIO_OUT);
    gpio_put(LCD_PIN_CS, 1);

    //先拉低，避免屏还没初始化完成时背光先亮
    gpio_init(LCD_PIN_BL);
    gpio_set_dir(LCD_PIN_BL, GPIO_OUT);
    gpio_put(LCD_PIN_BL, 0);

    //TE 是屏给 MCU 的输出信号，本程序里没有用到，所以初始化为输入，禁用上下拉
    gpio_init(LCD_PIN_TE);
    gpio_set_dir(LCD_PIN_TE, GPIO_IN);
    gpio_disable_pulls(LCD_PIN_TE);
}

static void lcd_init_spi(void)
{
    spi_init(LCD_SPI_PORT, LCD_SPI_BAUDRATE);
    gpio_set_function(LCD_PIN_SCK, GPIO_FUNC_SPI);
    gpio_set_function(LCD_PIN_MOSI, GPIO_FUNC_SPI);
    //定 SPI 格式，8 位数据，时钟空闲低电平，数据采样上升沿，MSB 先发
    spi_set_format(LCD_SPI_PORT, 8, SPI_CPOL_0, SPI_CPHA_0, SPI_MSB_FIRST);
}

//ST7789 最小可运行初始化。
static void lcd_init_panel(void)
{
    //对应 MADCTL (0x36) 控制扫描方向、行列映射、RGB/BGR 顺序。默认给0x00
    const uint8_t madctl = 0x00;
    //对应 COLMOD (0x3A) 0x55 表示 16-bit/pixel，RGB565
    const uint8_t colmod = 0x55;
    //硬件复位
    lcd_hard_reset();
    //软件复位
    lcd_write_command(ST7789_CMD_SWRESET);
    sleep_ms(150);
    //退出睡眠模式
    lcd_write_command(ST7789_CMD_SLPOUT);
    sleep_ms(120);
    //设置像素格式为 RGB565
    lcd_write_command_with_data(ST7789_CMD_COLMOD, &colmod, 1);
    sleep_ms(10);
    //设置扫描方向、行列映射、RGB/BGR 顺序
    lcd_write_command_with_data(ST7789_CMD_MADCTL, &madctl, 1);
    sleep_ms(10);
    //开显示反显
    lcd_write_command(ST7789_CMD_INVON);
    sleep_ms(10);
    //开显示
    lcd_write_command(ST7789_CMD_NORON);
    sleep_ms(10);
    //开显示输出
    lcd_write_command(ST7789_CMD_DISPON);
    sleep_ms(120);

    //打开背光
    gpio_put(LCD_PIN_BL, 1);
}

//显示当前颜色
static void lcd_show_current_color(void)
{
    const color_config_t *color = &g_color_table[g_color_index];

    lcd_fill_color(color->rgb565);
    printf("LCD color=%s index=%u\n", color->name, (unsigned)g_color_index);
}
//切换到下一个颜色
static void lcd_next_color(void)
{
    g_color_index = (g_color_index + 1u) % (sizeof(g_color_table) / sizeof(g_color_table[0]));
    lcd_show_current_color();
}

static void test_gpio_callback(uint gpio, uint32_t event_mask)
{
    const char *button_name = test_gpio_name_from_pin(gpio);
    const bool level = gpio_get(gpio);

    if (event_mask & GPIO_IRQ_EDGE_FALL) {
        const uint32_t now_ms = to_ms_since_boot(get_absolute_time());

        if ((now_ms - g_last_button_press_ms) >= BUTTON_DEBOUNCE_MS) {
            g_last_button_press_ms = now_ms;
            g_color_change_requested = true;
            printf("BUTTON %-6s gpio=%u edge=fall level=%u -> color step\n", button_name, gpio, level ? 1u : 0u);
        }
    }

    if (event_mask & GPIO_IRQ_EDGE_RISE) {
        printf("BUTTON %-6s gpio=%u edge=rise level=%u\n", button_name, gpio, level ? 1u : 0u);
    }
}

static void test_gpio_init(void)
{
    for (size_t i = 0; i < sizeof(g_button_table) / sizeof(g_button_table[0]); ++i) {
        test_gpio_init_one_input(g_button_table[i].gpio);
    }

    // SD_UI_PATCH: Register the shared callback once, then enable the same
    // edge mask on the remaining buttons.
    gpio_set_irq_enabled_with_callback(
        g_button_table[0].gpio,
        GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL,
        true,
        &test_gpio_callback
    );

    for (size_t i = 1; i < sizeof(g_button_table) / sizeof(g_button_table[0]); ++i) {
        gpio_set_irq_enabled(
            g_button_table[i].gpio,
            GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL,
            true
        );
    }

    printf("Button IRQ test ready\n");
    for (size_t i = 0; i < sizeof(g_button_table) / sizeof(g_button_table[0]); ++i) {
        printf("BUTTON %-6s gpio=%u armed\n", g_button_table[i].name, g_button_table[i].gpio);
    }
}

int main()
{
    stdio_init_all();
    sleep_ms(1500);

    printf("LCD bring-up start\n");

    //初始化LCD引脚
    lcd_init_pins();
    //初始化SPI总线
    lcd_init_spi();
    //初始化LCD面板
    lcd_init_panel();
    //显示当前颜色
    lcd_show_current_color();
    //初始化GPIO按键
    test_gpio_init();

    while (true) 
    {
        
        if (g_color_change_requested) 
        {
            // 处理颜色变化请求
            uint32_t flags = save_and_disable_interrupts();
            g_color_change_requested = false;
            restore_interrupts(flags);
            // 切换到下一个颜色
            lcd_next_color();
        }

        sleep_ms(10);
    }
}
