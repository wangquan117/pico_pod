#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "pico/stdlib.h"

#include "angle_sensor.h"
#include "ili9341_display.h"
#include "lcd1602_rgb.h"

// SD_UI_PATCH
// main.c 只做调度层工作：
// 1. 初始化各个模块；
// 2. 组织 ILI9341 的页面布局；
// 3. 轮询角度数据并同步刷新两块屏；
// 4. 保留英文串口日志，方便你做量测比对。

#define UI_UPDATE_PERIOD_MS 100u

#define UI_COLOR_BG 0x0841u
#define UI_COLOR_PANEL 0x1082u
#define UI_COLOR_LABEL 0xBDF7u
#define UI_COLOR_VALUE 0xFFE0u
#define UI_COLOR_ACCENT 0x07FFu

static void format_angle_text(char *buffer, size_t buffer_size, uint32_t angle_tenths)
{
    // SD_UI_PATCH: ILI9341 上统一用 ASCII 文本，避免特殊符号字库带来的额外维护。
    snprintf(
        buffer,
        buffer_size,
        "%4lu.%1lu DEG",
        (unsigned long)(angle_tenths / 10u),
        (unsigned long)(angle_tenths % 10u)
    );
}

static void format_voltage_text(char *buffer, size_t buffer_size, uint32_t voltage_mv)
{
    snprintf(buffer, buffer_size, "%4lu MV", (unsigned long)voltage_mv);
}

static void format_raw_text(char *buffer, size_t buffer_size, uint16_t raw)
{
    snprintf(buffer, buffer_size, "%4u", raw);
}

static uint16_t ui_center_x(const char *text, uint8_t scale)
{
    const uint16_t screen_width = ili9341_get_width();
    const uint16_t text_width = ili9341_text_width(text, scale);

    if (text_width >= screen_width) {
        return 0u;
    }

    return (uint16_t)((screen_width - text_width) / 2u);
}

static void ui_draw_static_background(void)
{
    const uint16_t screen_width = ili9341_get_width();

    // SD_UI_PATCH: 背景只画一次，后面只局部擦写数值区域，尽量避免肉眼可见闪烁。
    ili9341_fill_screen(UI_COLOR_BG);
    ili9341_fill_rect(10u, 10u, (uint16_t)(screen_width - 20u), 36u, UI_COLOR_PANEL);
    ili9341_fill_rect(10u, 58u, (uint16_t)(screen_width - 20u), 54u, UI_COLOR_PANEL);
    ili9341_fill_rect(10u, 118u, (uint16_t)(screen_width - 20u), 54u, UI_COLOR_PANEL);
    ili9341_fill_rect(10u, 178u, (uint16_t)(screen_width - 20u), 52u, UI_COLOR_PANEL);

    ili9341_draw_text_5x7(ui_center_x("ANGLE SENSOR", 3u), 18u, "ANGLE SENSOR", UI_COLOR_ACCENT, 3u);
    ili9341_draw_text_5x7(20u, 68u, "ADC", UI_COLOR_LABEL, 2u);
    ili9341_draw_text_5x7(20u, 128u, "VOLTAGE", UI_COLOR_LABEL, 2u);
    ili9341_draw_text_5x7(20u, 188u, "ANGLE", UI_COLOR_LABEL, 2u);
}


static void ui_draw_dynamic_values(const angle_sample_t *sample)
{
    char raw_text[8];
    char voltage_text[16];
    char angle_text[16];
    const uint16_t screen_width = ili9341_get_width();

    // SD_UI_PATCH: 屏幕上同时保留 raw / mV / degree 三个量，便于你判断问题到底
    // 出在传感器、电压链路还是角度映射公式。
    format_raw_text(raw_text, sizeof(raw_text), sample->raw);
    format_voltage_text(voltage_text, sizeof(voltage_text), sample->voltage_mv);
    format_angle_text(angle_text, sizeof(angle_text), sample->angle_tenths);

    // SD_UI_PATCH: 这里只擦除数值区，不动标签和框体，稳定性会比整屏重绘更好。
    ili9341_fill_rect(110u, 66u, 180u, 30u, UI_COLOR_PANEL);
    ili9341_fill_rect(150u, 126u, 140u, 30u, UI_COLOR_PANEL);
    ili9341_fill_rect(18u, 198u, (uint16_t)(screen_width - 36u), 34u, UI_COLOR_PANEL);
    // SD_UI_PATCH: 这里的坐标和缩放比例是根据上面静态布局的矩形区域来算的，保证数值居中。
    ili9341_draw_text_5x7(110u, 68u, raw_text, UI_COLOR_VALUE, 3u);
    ili9341_draw_text_5x7(150u, 128u, voltage_text, UI_COLOR_VALUE, 3u);
    ili9341_draw_text_5x7(ui_center_x(angle_text, 4u), 200u, angle_text, UI_COLOR_VALUE, 4u);
}


static void ui_update_lcd1602(const angle_sample_t *sample)
{
    static bool line_valid[2] = {false, false};
    static char last_line_0[LCD1602_COLUMNS + 1u];
    static char last_line_1[LCD1602_COLUMNS + 1u];
    char line_0[LCD1602_COLUMNS + 1u];
    char line_1[LCD1602_COLUMNS + 1u];

    snprintf(
        line_0,
        sizeof(line_0),
        "Angle %4lu.%1lu",
        (unsigned long)(sample->angle_tenths / 10u),
        (unsigned long)(sample->angle_tenths % 10u)
    );
    snprintf(
        line_1,
        sizeof(line_1),
        "ADC%4u %4lumV",
        sample->raw,
        (unsigned long)sample->voltage_mv
    );

    // SD_UI_PATCH: 1602 只在字符串变化时重写，避免无意义刷屏。
    if ((!line_valid[0]) || (strncmp(last_line_0, line_0, sizeof(last_line_0)) != 0)) {
        (void)lcd1602_rgb_write_line(0u, line_0);
        strncpy(last_line_0, line_0, sizeof(last_line_0) - 1u);
        last_line_0[sizeof(last_line_0) - 1u] = '\0';
        line_valid[0] = true;
    }

    if ((!line_valid[1]) || (strncmp(last_line_1, line_1, sizeof(last_line_1)) != 0)) {
        (void)lcd1602_rgb_write_line(1u, line_1);
        strncpy(last_line_1, line_1, sizeof(last_line_1) - 1u);
        last_line_1[sizeof(last_line_1) - 1u] = '\0';
        line_valid[1] = true;
    }
}

int main(void)
{
    angle_sample_t last_sample = {0u, 0u, 0u};
    bool lcd1602_ready;
    bool first_update = true;
    uint32_t last_update_ms = 0u;

    stdio_init_all();
    sleep_ms(300);

    printf("angle monitor start\n");
    printf("adc gpio=%u input=%u vref_mv=%u max_tenths=%u raw_min=%u raw_max=%u zero_deadband=%u\n",
           ANGLE_SENSOR_ADC_GPIO,
           ANGLE_SENSOR_ADC_INPUT,
           ANGLE_SENSOR_VREF_MV,
           ANGLE_SENSOR_MAX_TENTHS,
           ANGLE_SENSOR_RAW_MIN,
           ANGLE_SENSOR_RAW_MAX,
           ANGLE_SENSOR_RAW_ZERO_DEADBAND);

    // SD_UI_PATCH: 先把 ILI9341 静态页面立起来，再启动数据链路，开机观感更稳定。
    ili9341_init();
    ui_draw_static_background();

    angle_sensor_init();

    lcd1602_ready = lcd1602_rgb_init();
    printf("lcd1602 bus=i2c0 sda=GP%u scl=GP%u lcd_addr=0x%02X rgb_addr=0x%02X ready=%d\n",
           LCD1602_I2C_SDA_PIN,
           LCD1602_I2C_SCL_PIN,
           LCD1602_LCD_ADDR,
           LCD1602_RGB_ADDR,
           lcd1602_ready ? 1 : 0);

    while (true) {
        const uint32_t now_ms = to_ms_since_boot(get_absolute_time());

        if ((now_ms - last_update_ms) >= UI_UPDATE_PERIOD_MS) {
            // SD_UI_PATCH: 每 100ms 取一次稳态样本，既能跟手，也不会让屏幕过于频繁刷新。
            const angle_sample_t sample = angle_sensor_sample();

            last_update_ms = now_ms;

            if (first_update
                || (sample.raw != last_sample.raw)
                || (sample.voltage_mv != last_sample.voltage_mv)
                || (sample.angle_tenths != last_sample.angle_tenths)) {
                //刷新ILI9341屏幕
                ui_draw_dynamic_values(&sample);
                
                if (lcd1602_ready) {
                    //刷新1602屏幕
                    ui_update_lcd1602(&sample);
                }

                printf("angle_raw=%u voltage_mv=%lu angle_deg=%lu.%1lu\n",
                       sample.raw,
                       (unsigned long)sample.voltage_mv,
                       (unsigned long)(sample.angle_tenths / 10u),
                       (unsigned long)(sample.angle_tenths % 10u));

                last_sample = sample;
                first_update = false;
            }
        }

        sleep_ms(5);
    }
}
