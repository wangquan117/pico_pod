#ifndef ANGLE_SENSOR_H
#define ANGLE_SENSOR_H

#include <stdint.h>

// SD_UI_PATCH
// 角度传感器模块职责：
// 1. 初始化 GPIO27 / ADC1 采样链路。
// 2. 输出原始 ADC、换算电压和校准后的 0~3600.0 度。
// 3. 把 ADC 的零点偏移收进软件校准，不把它直接反映成角度误差。

// SD_UI_PATCH: 这些宏直接对应当前确认过的硬件接线，方便主流程打印日志，
// 也方便后续你自己做量测对照时快速定位。
#define ANGLE_SENSOR_ADC_GPIO 27u
#define ANGLE_SENSOR_ADC_INPUT 1u
#define ANGLE_SENSOR_VREF_MV 3300u
#define ANGLE_SENSOR_MAX_TENTHS 36000u

// SD_UI_PATCH: 这是当前实测得到的双点校准参数。
// - RAW_MIN: GPIO27 直接接地时 ADC 仍有约 15 counts 的零点偏移。
// - RAW_MAX: 当前先按 ADC 满量程处理；如果后面你量到最大端不是 4095，
//   只需要改这里，不必改主流程。
#define ANGLE_SENSOR_RAW_MIN 15u
#define ANGLE_SENSOR_RAW_MAX 4095u

// SD_UI_PATCH: 零点死区用于吃掉 RAW_MIN 附近 1~3 counts 的低端抖动。
// 目前你实测最小端会在 17~18 附近来回跳，所以这里先给 3 counts：
// raw <= RAW_MIN + 3 时，显示直接归 0.0 度。
#define ANGLE_SENSOR_RAW_ZERO_DEADBAND 3u

typedef struct {
    uint16_t raw;
    uint32_t voltage_mv;
    uint32_t angle_tenths;
} angle_sample_t;

void angle_sensor_init(void);
angle_sample_t angle_sensor_sample(void);

#endif
