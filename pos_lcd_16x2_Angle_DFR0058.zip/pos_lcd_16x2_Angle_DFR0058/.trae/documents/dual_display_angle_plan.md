# 双屏角度显示改造计划

## Summary

当前工程 `pos_lcd_angle.c` 仍是“震动传感器 + 外接 LED + ILI9341 整屏变色”的旧框架。目标是把它收束为单一职责版本：仅保留并复用已验证可点亮的 ILI9341 SPI 驱动，新增 DFR0058 模拟角度传感器采样与 DFR0464 I2C 1602 RGB LCD 显示，让 ILI9341 和 LCD1602 同步显示 `GPIO27 / ADC1` 映射后的 `0~3600°` 角度值。ILI9341 默认按 `90° 横屏` 布局实现，并继续保留方向宏可切换能力。

## Current State Analysis

1. 当前工程只有一个主要源码文件：`d:\raspberry_pi_pico\pos_pico_test\my_demo\pos_lcd_16x2_Angle_DFR0058\pos_lcd_angle.c`，CMake 也只编译这个文件。
2. 现有 `pos_lcd_angle.c` 已具备以下可复用能力：
   - ILI9341 的 SPI 引脚与初始化序列已经和当前硬件对齐：
     - `RST=21`
     - `DC=20`
     - `CS=17`
     - `SCK=18`
     - `MOSI=19`
     - `BL=22`
   - 默认旋转宏 `LCD_ROTATION_DEGREES` 已存在，当前 `90°` 的 `MADCTL=0x28` 已配置好。
   - 已有 `lcd_fill_color()` 等底层全屏填充基础能力。
3. 当前文件中仍残留大量与新需求无关的旧逻辑：
   - `VIBRATION_SENSOR_GPIO`
   - `LED_OUTPUT_GPIO`
   - 震动输入初始化/判定
   - LED 保持点亮逻辑
   - LCD 红绿整屏状态显示逻辑
4. 当前工程尚未接入：
   - `hardware/adc.h`
   - `hardware/i2c.h`
   - LCD1602 驱动
   - ILI9341 文本绘制能力
5. `CMakeLists.txt` 当前只链接了：
   - `pico_stdlib`
   - `hardware_spi`
   因此后续实现必须补充 `hardware_adc` 与 `hardware_i2c`。
6. 参考工程中已存在两块可直接借鉴的成熟实现：
   - `d:\raspberry_pi_pico\pos_pico_test\my_demo\pos_lcd_XyzSensor_SEN0224\pos_lcd_xyz.c`
     - 已验证包含 ILI9341 的 `lcd_fill_rect()`、`lcd_draw_char_5x7()`、`lcd_draw_text_5x7()` 一套轻量文本显示路径。
   - `d:\raspberry_pi_pico\pos_pico_test\my_demo\pos_lcd_VolDetection_DFR0051\pos_lcd_VolDetection.c`
     - 已验证包含 RP2040 ADC 初始化、丢弃首样本、均值采样的稳态读取方式。
7. 根据 DFRobot 官方资料：
   - `DFR0058` 是模拟量输出、多圈 `0~3600°` 角度传感器。
   - `DFR0464` 是 I2C RGB LCD1602，不是常见的 PCF8574 `0x27` 背包方案，应按 DFRobot `RGBLCD1602` 风格实现，优先兼容其 RGB 地址版本；资料中可见 V2.0 RGB 地址为 `0x2D`。

## Assumptions & Decisions

1. 角度显示口径采用用户已确认的 `0~3600°` 全量程映射。
2. ILI9341 默认布局采用用户已确认的 `90° 横屏`，并保留 `LCD_ROTATION_DEGREES` 宏切换 `0/90/180/270` 的能力。
3. DFR0058 接在 `GPIO27`，即 RP2040 `ADC1`，程序内部固定使用：
   - `ANGLE_SENSOR_ADC_GPIO = 27`
   - `ANGLE_SENSOR_ADC_INPUT = 1`
4. DFR0464 接在 `J5`，即：
   - `SDA = GPIO4`
   - `SCL = GPIO5`
   - 使用 `i2c0`
5. LCD1602 采用“最小可用优先”的驱动策略：
   - 第一优先级：确保字符显示可靠。
   - 第二优先级：设置固定 RGB 背光颜色作为工作状态标识。
   - 不把花哨背光动画纳入本次范围。
6. 为减少闪烁，双屏刷新采用“静态背景 + 局部更新”策略：
   - ILI9341 上电后只绘制一次背景框架。
   - 后续仅擦除并重绘数值区域，不做整屏循环刷新。
   - LCD1602 仅在内容变化时刷新对应行。
7. 串口日志保持英文，符合当前项目习惯与用户偏好。

## Proposed Changes

### 1. 修改 `d:\raspberry_pi_pico\pos_pico_test\my_demo\pos_lcd_16x2_Angle_DFR0058\CMakeLists.txt`

#### What

补充本工程所需硬件库链接项。

#### Why

新功能将新增 ADC 采样与 I2C LCD1602 通讯，现有链接项不足。

#### How

在 `target_link_libraries(pos_lcd_angle ...)` 中加入：

- `hardware_adc`
- `hardware_i2c`

不修改其余项目结构，继续保持单文件构建。

### 2. 重写 `d:\raspberry_pi_pico\pos_pico_test\my_demo\pos_lcd_16x2_Angle_DFR0058\pos_lcd_angle.c`

#### What

把现有“震动 + LED 状态机”代码整体替换为“角度采样 + 双屏显示”实现，但保留并复用当前已可工作的 ILI9341 底层 SPI 驱动框架。

#### Why

当前文件职责混杂，而且旧逻辑与目标需求无关。直接在现有震动/LED 状态机上叠加会增加维护成本，也不利于用户后续继续按硬件参数做底层调试。

#### How

按以下结构组织：

1. **保留并整理 ILI9341 底层驱动**
   - 继续保留并使用当前已验证的：
     - GPIO 初始化
     - SPI 初始化
     - ILI9341 上电初始化序列
     - `LCD_ROTATION_DEGREES`
   - 从参考工程 `pos_lcd_xyz.c` 引入最小文本绘制能力：
     - `lcd_fill_rect()`
     - `glyph_5x7_t`
     - `lcd_draw_char_5x7()`
     - `lcd_draw_text_5x7()`
   - 字符集仅保留本任务必需字符，避免无意义膨胀：
     - 数字 `0-9`
     - 大写字母中需要的字符，例如 `A D G L N`
     - 小写需要的字符，例如 `e g l n o`
     - 标点与符号：空格、冒号、点号、度数替代文本等
   - 若直接显示 `°` 不方便，则统一显示为 ASCII 形式，例如：
     - `Angle`
     - `1234.5 deg`

2. **删除旧震动/LED 逻辑**
   - 删除：
     - 震动 GPIO 配置表
     - `vibration_*` 全部函数
     - `led_*` 全部函数
     - `g_led_hold_until`
     - 红绿整屏状态 UI
   - 删除无关宏与颜色定义，只保留新 UI 所需颜色。

3. **新增 DFR0058 ADC 采样链路**
   - 引入 `hardware/adc.h`。
   - 新增固定配置：
     - `ANGLE_SENSOR_ADC_GPIO 27`
     - `ANGLE_SENSOR_ADC_INPUT 1`
     - `ANGLE_SENSOR_SAMPLE_COUNT`，计划取 16 或 32 的均值采样
     - `ANGLE_SENSOR_VREF_MV 3300`
     - `ANGLE_SENSOR_ADC_FS 4095`
     - `ANGLE_SENSOR_MAX_DEGREE 3600`
   - 初始化流程参考 `pos_lcd_VolDetection_DFR0051`：
     - `gpio_init()`
     - 关闭上下拉
     - `adc_init()`
     - `adc_gpio_init(27)`
     - `adc_select_input(1)`
     - 首样本丢弃
   - 读取流程：
     - 先 `adc_select_input(1)`
     - 适度 `sleep_us()`
     - 丢弃 1 次读数
     - 累加 N 次 `adc_read()`
     - 取均值作为稳定值
   - 映射公式：
     - `angle_tenths = raw * 36000 / 4095`
     - 显示时格式化为 `xxxx.x deg`
   - 同时保留原始 ADC 值与电压毫伏值作为日志输出，便于用户量测比对。

4. **新增 DFR0464 I2C LCD1602 驱动**
   - 引入 `hardware/i2c.h`。
   - 固定总线：
     - `I2C port = i2c0`
     - `SDA = 4`
     - `SCL = 5`
     - 初始波特率先取 `100000`
   - 驱动实现采用“最小子集”：
     - `lcd1602_i2c_init_bus()`
     - `lcd1602_send_command()`
     - `lcd1602_send_data()`
     - `lcd1602_init()`
     - `lcd1602_set_cursor()`
     - `lcd1602_print()`
     - `lcd1602_clear_line()`
     - `lcd1602_set_rgb()`（固定颜色即可）
   - 地址兼容策略：
     - 字符控制器按 DFRobot `RGBLCD1602` 方案实现；
     - 背光控制优先按 DFR0464 V2.0 常见 RGB 地址 `0x2D`；
     - 如果代码中需要字符控制地址与背光控制地址拆分，则在宏区集中定义，并写清注释，便于后续按实物版本微调。
   - 文本布局建议：
     - 第 1 行：`Angle:1234.5`
     - 第 2 行：`ADC:4095`
   - 保证每行不超过 16 个字符。

5. **新增 ILI9341 角度显示 UI**
   - 上电只绘制一次静态背景：
     - 标题区域：`Angle Sensor`
     - 标签区域：`ADC`、`Voltage`、`Angle`
   - 数值区域使用局部重绘：
     - 先 `lcd_fill_rect()` 擦除旧数字区域
     - 再 `lcd_draw_text_5x7()` 重绘新值
   - 默认横屏下规划大号角度显示，辅以较小的 ADC / 电压行。
   - UI 保持纯色高对比，便于用户肉眼快速确认刷新是否稳定。

6. **重构主循环**
   - 启动顺序：
     1. `stdio_init_all()`
     2. ILI9341 初始化
     3. ADC 初始化
     4. I2C 总线与 LCD1602 初始化
     5. 绘制 ILI9341 静态背景
     6. 首次读取并同步双屏显示
   - 周期性轮询：
     - 采样周期先设为约 `100ms`
   - 仅当以下任一内容变化超过阈值时才刷新：
     - `raw adc`
     - `mv`
     - `angle_tenths`
   - 串口输出英文日志，例如：
     - `angle_raw=2048 voltage_mv=1650 angle_deg=1800.4`

### 3. 代码注释与补丁标记

#### What

在所有新增或关键改动处保留清晰注释，并使用用户偏好的 `SD_UI_PATCH` 标记。

#### Why

用户希望后续能自己复审、测量和继续微调，不希望得到难以追踪来源的“黑盒”代码。

#### How

重点在以下位置添加 `SD_UI_PATCH` 风格注释：

- ADC 初始化与换算公式
- DFR0464 地址/总线配置
- ILI9341 局部刷新策略
- 角度格式化与显示布局

## Verification Steps

1. 代码级检查
   - 确认 `CMakeLists.txt` 已链接 `hardware_adc` 和 `hardware_i2c`。
   - 确认源码不再残留旧震动/LED 逻辑入口。
2. 编译检查
   - 由执行阶段运行构建，确认无缺失头文件、未定义符号或库链接错误。
3. 上板功能验证
   - 上电后 ILI9341 正常点亮，默认 `90°` 横屏。
   - ILI9341 先显示固定背景，再稳定显示角度数值，没有持续整屏闪烁。
   - LCD1602 正常初始化并显示两行内容。
   - 旋转 DFR0058 时：
     - ILI9341 与 LCD1602 数值同步变化；
     - 串口日志中的 raw / mv / angle 同步变化；
     - 0~满量程可覆盖接近 `0~3600°`。
4. 异常定位预留
   - 若 LCD1602 无字符但 I2C 总线正常，优先检查模块版本对应的地址宏。
   - 若角度数值抖动明显，优先提高 ADC 平均样本数或放慢刷新周期。
   - 若 ILI9341 方向不符，仅调整 `LCD_ROTATION_DEGREES`，不重写初始化序列。
