#include "ili9341_display.h"

#include <stddef.h>
#include <string.h>

#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "hardware/spi.h"

// SD_UI_PATCH
// 这个模块只负责 ILI9341 的底层驱动和最小文本绘制：
// 1. 保留当前板子已经验证可工作的 SPI 时序和初始化序列；
// 2. 提供填屏、填矩形、文本绘制这些上层 UI 会直接用到的接口；
// 3. 不把页面布局逻辑放进来，保持驱动层职责单一。

#define LCD_SPI_PORT spi0
#define LCD_SPI_BAUDRATE 40000000u

// 43.2 / 0.18 = 240
#define LCD_PANEL_WIDTH 240u
// 57.6 / 0.18 = 320
#define LCD_PANEL_HEIGHT 320u

#if LCD_ROTATION_DEGREES == 0u
#define LCD_WIDTH LCD_PANEL_WIDTH
#define LCD_HEIGHT LCD_PANEL_HEIGHT
#define LCD_ILI9341_MADCTL 0x48u
#elif LCD_ROTATION_DEGREES == 90u
#define LCD_WIDTH LCD_PANEL_HEIGHT
#define LCD_HEIGHT LCD_PANEL_WIDTH
#define LCD_ILI9341_MADCTL 0x28u
#elif LCD_ROTATION_DEGREES == 180u
#define LCD_WIDTH LCD_PANEL_WIDTH
#define LCD_HEIGHT LCD_PANEL_HEIGHT
#define LCD_ILI9341_MADCTL 0x88u
#elif LCD_ROTATION_DEGREES == 270u
#define LCD_WIDTH LCD_PANEL_HEIGHT
#define LCD_HEIGHT LCD_PANEL_WIDTH
#define LCD_ILI9341_MADCTL 0xE8u
#else
#error "LCD_ROTATION_DEGREES must be one of 0, 90, 180, or 270"
#endif

#define ILI9341_CMD_SWRESET 0x01u
#define ILI9341_CMD_SLPOUT  0x11u
#define ILI9341_CMD_DISPON  0x29u
#define ILI9341_CMD_CASET   0x2Au
#define ILI9341_CMD_PASET   0x2Bu
#define ILI9341_CMD_RAMWR   0x2Cu
#define ILI9341_CMD_MADCTL  0x36u
#define ILI9341_CMD_PIXFMT  0x3Au
#define ILI9341_CMD_FRMCTR1 0xB1u
#define ILI9341_CMD_DFUNCTR 0xB6u
#define ILI9341_CMD_PWCTR1  0xC0u
#define ILI9341_CMD_PWCTR2  0xC1u
#define ILI9341_CMD_VMCTR1  0xC5u
#define ILI9341_CMD_VMCTR2  0xC7u
#define ILI9341_CMD_GAMMASET 0x26u
#define ILI9341_CMD_GMCTRP1 0xE0u
#define ILI9341_CMD_GMCTRN1 0xE1u

typedef struct {
    char c;
    uint8_t rows[7];
} glyph_5x7_t;

// SD_UI_PATCH: 这里继续只保留当前 UI 需要的最小字库，避免驱动层变成难复审的大表。
static const glyph_5x7_t g_font_table[] = {
    {' ', {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}},
    {'.', {0x00, 0x00, 0x00, 0x00, 0x00, 0x0C, 0x0C}},
    {'0', {0x0E, 0x11, 0x13, 0x15, 0x19, 0x11, 0x0E}},
    {'1', {0x04, 0x0C, 0x04, 0x04, 0x04, 0x04, 0x0E}},
    {'2', {0x0E, 0x11, 0x01, 0x02, 0x04, 0x08, 0x1F}},
    {'3', {0x1F, 0x02, 0x04, 0x02, 0x01, 0x11, 0x0E}},
    {'4', {0x02, 0x06, 0x0A, 0x12, 0x1F, 0x02, 0x02}},
    {'5', {0x1F, 0x10, 0x1E, 0x01, 0x01, 0x11, 0x0E}},
    {'6', {0x06, 0x08, 0x10, 0x1E, 0x11, 0x11, 0x0E}},
    {'7', {0x1F, 0x01, 0x02, 0x04, 0x08, 0x08, 0x08}},
    {'8', {0x0E, 0x11, 0x11, 0x0E, 0x11, 0x11, 0x0E}},
    {'9', {0x0E, 0x11, 0x11, 0x0F, 0x01, 0x02, 0x0C}},
    {'A', {0x0E, 0x11, 0x11, 0x1F, 0x11, 0x11, 0x11}},
    {'C', {0x0E, 0x11, 0x10, 0x10, 0x10, 0x11, 0x0E}},
    {'D', {0x1C, 0x12, 0x11, 0x11, 0x11, 0x12, 0x1C}},
    {'E', {0x1F, 0x10, 0x10, 0x1E, 0x10, 0x10, 0x1F}},
    {'G', {0x0E, 0x11, 0x10, 0x17, 0x11, 0x11, 0x0F}},
    {'L', {0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x1F}},
    {'M', {0x11, 0x1B, 0x15, 0x15, 0x11, 0x11, 0x11}},
    {'N', {0x11, 0x11, 0x19, 0x15, 0x13, 0x11, 0x11}},
    {'O', {0x0E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0E}},
    {'R', {0x1E, 0x11, 0x11, 0x1E, 0x14, 0x12, 0x11}},
    {'S', {0x0F, 0x10, 0x10, 0x0E, 0x01, 0x01, 0x1E}},
    {'T', {0x1F, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04}},
    {'V', {0x11, 0x11, 0x11, 0x11, 0x11, 0x0A, 0x04}},
};

static const uint8_t *font_lookup(char c)
{
    // SD_UI_PATCH: 找不到字符时回退为空格，避免 UI 层误传字符后出现杂点。
    for (size_t i = 0; i < sizeof(g_font_table) / sizeof(g_font_table[0]); ++i) {
        if (g_font_table[i].c == c) {
            return g_font_table[i].rows;
        }
    }

    return g_font_table[0].rows;
}

static inline void lcd_select(void)
{
    gpio_put(LCD_PIN_CS, 0);
}

static inline void lcd_deselect(void)
{
    gpio_put(LCD_PIN_CS, 1);
}

static void lcd_write_bytes(const uint8_t *data, size_t length)
{
    if (length == 0u) {
        return;
    }

    spi_write_blocking(LCD_SPI_PORT, data, length);
}

static void lcd_write_command(uint8_t command)
{
    gpio_put(LCD_PIN_DC, 0);
    lcd_select();
    lcd_write_bytes(&command, 1u);
    lcd_deselect();
}

static void lcd_write_data(const uint8_t *data, size_t length)
{
    gpio_put(LCD_PIN_DC, 1);
    lcd_select();
    lcd_write_bytes(data, length);
    lcd_deselect();
}

static void lcd_write_command_with_data(uint8_t command, const uint8_t *data, size_t length)
{
    lcd_write_command(command);
    lcd_write_data(data, length);
}

static void lcd_hard_reset(void)
{
    // SD_UI_PATCH: 原理图里 LCD_RST 默认会被拉低，所以固件必须明确拉高释放复位。
    gpio_put(LCD_PIN_RST, 0);
    sleep_ms(30);
    gpio_put(LCD_PIN_RST, 1);
    sleep_ms(120);
}

static void lcd_set_address_window(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1)
{
    uint8_t buffer[4];

    // SD_UI_PATCH: ILI9341 先设列地址，再设行地址，最后发 RAMWR 进入显存写入态。
    buffer[0] = (uint8_t)(x0 >> 8);
    buffer[1] = (uint8_t)(x0 & 0xFFu);
    buffer[2] = (uint8_t)(x1 >> 8);
    buffer[3] = (uint8_t)(x1 & 0xFFu);
    lcd_write_command_with_data(ILI9341_CMD_CASET, buffer, sizeof(buffer));

    buffer[0] = (uint8_t)(y0 >> 8);
    buffer[1] = (uint8_t)(y0 & 0xFFu);
    buffer[2] = (uint8_t)(y1 >> 8);
    buffer[3] = (uint8_t)(y1 & 0xFFu);
    lcd_write_command_with_data(ILI9341_CMD_PASET, buffer, sizeof(buffer));

    lcd_write_command(ILI9341_CMD_RAMWR);
}

void ili9341_fill_screen(uint16_t rgb565)
{
    enum { PIXELS_PER_CHUNK = 64 };
    uint8_t chunk[PIXELS_PER_CHUNK * 2];
    const uint8_t msb = (uint8_t)(rgb565 >> 8);
    const uint8_t lsb = (uint8_t)(rgb565 & 0xFFu);
    size_t remaining_pixels = (size_t)LCD_WIDTH * (size_t)LCD_HEIGHT;

    for (size_t i = 0; i < PIXELS_PER_CHUNK; ++i) {
        chunk[i * 2] = msb;
        chunk[i * 2 + 1] = lsb;
    }

    // SD_UI_PATCH: 全屏填充用于开机清背景，分块写入是为了避免一次性占用过大栈空间。
    lcd_set_address_window(0u, 0u, (uint16_t)(LCD_WIDTH - 1u), (uint16_t)(LCD_HEIGHT - 1u));
    gpio_put(LCD_PIN_DC, 1);
    lcd_select();

    while (remaining_pixels > 0u) {
        const size_t pixels_this_round = remaining_pixels > PIXELS_PER_CHUNK ? PIXELS_PER_CHUNK : remaining_pixels;
        lcd_write_bytes(chunk, pixels_this_round * 2u);
        remaining_pixels -= pixels_this_round;
    }

    lcd_deselect();
}

//x,y左上角起点，width,height高度，rgb565颜色
void ili9341_fill_rect(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint16_t rgb565)
{
    enum { PIXELS_PER_CHUNK = 64 };
    uint8_t chunk[PIXELS_PER_CHUNK * 2];
    uint16_t x1;
    uint16_t y1;
    size_t total_pixels;
    size_t remaining_pixels;
    const uint8_t msb = (uint8_t)(rgb565 >> 8);
    const uint8_t lsb = (uint8_t)(rgb565 & 0xFFu);

    if ((width == 0u) || (height == 0u)) {
        return;
    }

    if ((x >= LCD_WIDTH) || (y >= LCD_HEIGHT)) {
        return;
    }

    x1 = (uint16_t)(x + width - 1u);
    y1 = (uint16_t)(y + height - 1u);
    if (x1 >= LCD_WIDTH) {
        x1 = (uint16_t)(LCD_WIDTH - 1u);
    }
    if (y1 >= LCD_HEIGHT) {
        y1 = (uint16_t)(LCD_HEIGHT - 1u);
    }

    total_pixels = (size_t)(x1 - x + 1u) * (size_t)(y1 - y + 1u);
    remaining_pixels = total_pixels;

    for (size_t i = 0; i < PIXELS_PER_CHUNK; ++i) {
        chunk[i * 2] = msb;
        chunk[i * 2 + 1] = lsb;
    }

    // SD_UI_PATCH: 局部矩形填充是当前 UI 防闪烁的核心接口。
    lcd_set_address_window(x, y, x1, y1);
    gpio_put(LCD_PIN_DC, 1);
    lcd_select();

    while (remaining_pixels > 0u) {
        const size_t pixels_this_round = remaining_pixels > PIXELS_PER_CHUNK ? PIXELS_PER_CHUNK : remaining_pixels;
        lcd_write_bytes(chunk, pixels_this_round * 2u);
        remaining_pixels -= pixels_this_round;
    }

    lcd_deselect();
}

// x,y左上角起点，rgb565颜色，scale缩放比例，把参数C画出来
static void ili9341_draw_char_5x7(uint16_t x, uint16_t y, char c, uint16_t rgb565, uint8_t scale)
{
    const uint8_t *glyph = font_lookup(c);

    if (scale == 0u) {
        return;
    }

    // SD_UI_PATCH: 当前字体是点阵放大方案，代码直观，后续你自己增减字形也方便。
    for (uint8_t row = 0u; row < 7u; ++row) {
        for (uint8_t col = 0u; col < 5u; ++col) {
            if (glyph[row] & (uint8_t)(1u << (4u - col))) {
                ili9341_fill_rect(
                    (uint16_t)(x + col * scale),
                    (uint16_t)(y + row * scale),
                    scale,
                    scale,
                    rgb565
                );
            }
        }
    }
}

//文字x,y左上角起点，rgb565颜色，scale缩放比例，在指定位置，用 5x7 点阵字体画一串字符串
void ili9341_draw_text_5x7(uint16_t x, uint16_t y, const char *text, uint16_t rgb565, uint8_t scale)
{
    uint16_t cursor_x = x;

    while (*text != '\0') {
        ili9341_draw_char_5x7(cursor_x, y, *text, rgb565, scale);
        cursor_x = (uint16_t)(cursor_x + (uint16_t)(6u * scale));
        ++text;
    }
}


uint16_t ili9341_text_width(const char *text, uint8_t scale)
{
    const size_t length = strlen(text);

    if (length == 0u) {
        return 0u;
    }

    return (uint16_t)((length * 6u - 1u) * scale);
}

//为ili9341_get_width函数添加中文注释说明获取屏幕宽度
uint16_t ili9341_get_width(void)
{
    return (uint16_t)LCD_WIDTH;
}

//为ili9341_get_height函数添加中文注释说明获取屏幕高度
uint16_t ili9341_get_height(void)
{
    return (uint16_t)LCD_HEIGHT;
}

void ili9341_init(void)
{
    const uint8_t madctl = LCD_ILI9341_MADCTL;
    const uint8_t pixfmt = 0x55u;
    static const uint8_t power_b[] = {0x00u, 0xC1u, 0x30u};
    static const uint8_t power_seq[] = {0x64u, 0x03u, 0x12u, 0x81u};
    static const uint8_t driver_timing_a[] = {0x85u, 0x00u, 0x78u};
    static const uint8_t power_a[] = {0x39u, 0x2Cu, 0x00u, 0x34u, 0x02u};
    static const uint8_t pump_ratio[] = {0x20u};
    static const uint8_t driver_timing_b[] = {0x00u, 0x00u};
    static const uint8_t frame_rate[] = {0x00u, 0x18u};
    static const uint8_t display_func[] = {0x08u, 0x82u, 0x27u};
    static const uint8_t power_ctrl_1[] = {0x23u};
    static const uint8_t power_ctrl_2[] = {0x10u};
    static const uint8_t vcom_ctrl_1[] = {0x3Eu, 0x28u};
    static const uint8_t vcom_ctrl_2[] = {0x86u};
    static const uint8_t gamma_curve[] = {0x01u};
    static const uint8_t positive_gamma[] = {
        0x0Fu, 0x31u, 0x2Bu, 0x0Cu, 0x0Eu,
        0x08u, 0x4Eu, 0xF1u, 0x37u, 0x07u,
        0x10u, 0x03u, 0x0Eu, 0x09u, 0x00u
    };
    static const uint8_t negative_gamma[] = {
        0x00u, 0x0Eu, 0x14u, 0x03u, 0x11u,
        0x07u, 0x31u, 0xC1u, 0x48u, 0x08u,
        0x0Fu, 0x0Cu, 0x31u, 0x36u, 0x0Fu
    };

    // SD_UI_PATCH: 这里把 GPIO、SPI、面板初始化放在同一个入口中，main 只需调用一次。
    gpio_init(LCD_PIN_RST);
    gpio_set_dir(LCD_PIN_RST, GPIO_OUT);
    gpio_put(LCD_PIN_RST, 0);

    gpio_init(LCD_PIN_DC);
    gpio_set_dir(LCD_PIN_DC, GPIO_OUT);
    gpio_put(LCD_PIN_DC, 1);

    gpio_init(LCD_PIN_CS);
    gpio_set_dir(LCD_PIN_CS, GPIO_OUT);
    gpio_put(LCD_PIN_CS, 1);

    gpio_init(LCD_PIN_BL);
    gpio_set_dir(LCD_PIN_BL, GPIO_OUT);
    gpio_put(LCD_PIN_BL, 0);

    spi_init(LCD_SPI_PORT, LCD_SPI_BAUDRATE);
    gpio_set_function(LCD_PIN_SCK, GPIO_FUNC_SPI);
    gpio_set_function(LCD_PIN_MOSI, GPIO_FUNC_SPI);
    spi_set_format(LCD_SPI_PORT, 8, SPI_CPOL_0, SPI_CPHA_0, SPI_MSB_FIRST);

    //硬件复位 ILI9341
    lcd_hard_reset();
    //寄存器复位
    lcd_write_command(ILI9341_CMD_SWRESET);
    sleep_ms(150);

    // SD_UI_PATCH: 这一组电源、时序和 Gamma 参数就是当前板子上已经验证能点亮
    //参考链接：https://raw.githubusercontent.com/adafruit/Adafruit_ILI9341/master/Adafruit_ILI9341.cpp
    // ILI9341 的序列，拆分文件时不改它的行为，只做结构整理。
    lcd_write_command_with_data(0xCFu, power_b, sizeof(power_b));
    lcd_write_command_with_data(0xEDu, power_seq, sizeof(power_seq));
    lcd_write_command_with_data(0xE8u, driver_timing_a, sizeof(driver_timing_a));
    lcd_write_command_with_data(0xCBu, power_a, sizeof(power_a));
    lcd_write_command_with_data(0xF7u, pump_ratio, sizeof(pump_ratio));
    lcd_write_command_with_data(0xEAu, driver_timing_b, sizeof(driver_timing_b));
    lcd_write_command_with_data(ILI9341_CMD_PWCTR1, power_ctrl_1, sizeof(power_ctrl_1));
    lcd_write_command_with_data(ILI9341_CMD_PWCTR2, power_ctrl_2, sizeof(power_ctrl_2));
    lcd_write_command_with_data(ILI9341_CMD_VMCTR1, vcom_ctrl_1, sizeof(vcom_ctrl_1));
    lcd_write_command_with_data(ILI9341_CMD_VMCTR2, vcom_ctrl_2, sizeof(vcom_ctrl_2));
    lcd_write_command_with_data(ILI9341_CMD_FRMCTR1, frame_rate, sizeof(frame_rate));
    lcd_write_command_with_data(ILI9341_CMD_DFUNCTR, display_func, sizeof(display_func));
    lcd_write_command_with_data(ILI9341_CMD_GAMMASET, gamma_curve, sizeof(gamma_curve));
    lcd_write_command_with_data(ILI9341_CMD_GMCTRP1, positive_gamma, sizeof(positive_gamma));
    lcd_write_command_with_data(ILI9341_CMD_GMCTRN1, negative_gamma, sizeof(negative_gamma));
    lcd_write_command_with_data(ILI9341_CMD_PIXFMT, &pixfmt, 1u);
    sleep_ms(10);
    lcd_write_command_with_data(ILI9341_CMD_MADCTL, &madctl, 1u);
    sleep_ms(10);

    lcd_write_command(ILI9341_CMD_SLPOUT);
    sleep_ms(120);
    lcd_write_command(ILI9341_CMD_DISPON);
    sleep_ms(120);

    gpio_put(LCD_PIN_BL, 1);
}
