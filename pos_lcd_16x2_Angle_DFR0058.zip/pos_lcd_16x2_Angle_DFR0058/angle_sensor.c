#include "angle_sensor.h"

#include "pico/stdlib.h"
#include "hardware/adc.h"
#include "hardware/gpio.h"

// SD_UI_PATCH
// 当前板子上，GPIO27 直接短接 GND 时 ADC 仍会稳定读到约 15 counts。
// 所以这里不再用“0~4095 直接映射 0~3600.0 度”，而是改成：
// 1. raw <= RAW_MIN + ZERO_DEADBAND -> 0.0 度
// 2. raw >= RAW_MAX                 -> 3600.0 度
// 3. 中间区间按双点线性插值
// 这样既能扣掉 ADC 自身零点偏移，也能把零点附近 1~3 counts 的抖动压成真正归零。

// SD_UI_PATCH: 采样数适当拉高一点，可以把电位器轻微抖动先在 ADC 侧做一次均值。
#define ANGLE_SENSOR_SAMPLE_COUNT 32u
#define ANGLE_SENSOR_ADC_FS 4095u

static uint16_t angle_sensor_read_raw(void)
{
    uint32_t sum = 0u;

    adc_select_input(ANGLE_SENSOR_ADC_INPUT);
    sleep_us(200);

    // SD_UI_PATCH: 丢弃首样本，避免通道切换后的残留影响本次结果。
    (void)adc_read();
    // 采集32次
    for (uint32_t i = 0u; i < ANGLE_SENSOR_SAMPLE_COUNT; ++i) {
        sum += adc_read();
    }
    //32次采样取平均
    return (uint16_t)(sum / ANGLE_SENSOR_SAMPLE_COUNT);
}

static uint32_t angle_sensor_raw_to_mv(uint16_t raw)
{
    return ((uint32_t)raw * ANGLE_SENSOR_VREF_MV) / ANGLE_SENSOR_ADC_FS;
}

static uint32_t angle_sensor_raw_to_tenths(uint16_t raw)
{
    const uint32_t raw_min = ANGLE_SENSOR_RAW_MIN;
    const uint32_t raw_max = ANGLE_SENSOR_RAW_MAX;
    const uint32_t zero_deadband = ANGLE_SENSOR_RAW_ZERO_DEADBAND;
    const uint32_t display_zero_limit = raw_min + zero_deadband;
    uint32_t calibrated_raw;
    uint32_t calibrated_span;

    // SD_UI_PATCH: 先吃掉零点附近的小范围噪声。按你当前实测，17~18 counts
    // 仍属于 GPIO27 接地时的底噪范围，所以这里一并显示为 0.0 度。
    if (raw <= display_zero_limit) {
        return 0u;
    }

    // SD_UI_PATCH: 高于满量程校准值时直接钳到 3600.0 度，避免末端超量程。
    if (raw >= raw_max) {
        return ANGLE_SENSOR_MAX_TENTHS;
    }

    // SD_UI_PATCH: 真正进入角度映射的起点，从“零点 + 死区”之后开始算。
    calibrated_raw = (uint32_t)raw - display_zero_limit;
    calibrated_span = raw_max - display_zero_limit;

    if (calibrated_span == 0u) {
        return 0u;
    }

    // SD_UI_PATCH: 双点线性校准，先减去零点偏移，再映射到完整 10 圈角度范围。
    return (calibrated_raw * ANGLE_SENSOR_MAX_TENTHS + (calibrated_span / 2u)) / calibrated_span;
}

void angle_sensor_init(void)
{
    // SD_UI_PATCH: GPIO27 作为 ADC1 输入，不需要上下拉，尽量保持模拟节点干净。
    gpio_init(ANGLE_SENSOR_ADC_GPIO);
    gpio_set_dir(ANGLE_SENSOR_ADC_GPIO, GPIO_IN);
    gpio_disable_pulls(ANGLE_SENSOR_ADC_GPIO);

    adc_init();
    adc_gpio_init(ANGLE_SENSOR_ADC_GPIO);
    adc_set_clkdiv(0.0f);
    adc_select_input(ANGLE_SENSOR_ADC_INPUT);
    sleep_ms(2);

    // 上电后的第一笔读数通常只用来稳定 ADC 状态。
    (void)adc_read();
}

angle_sample_t angle_sensor_sample(void)
{
    angle_sample_t sample;

    // SD_UI_PATCH: raw / voltage_mv 保持原始物理量，方便你继续拿串口和万用表对照；
    // angle_tenths 则使用校准后的显示口径。
    sample.raw = angle_sensor_read_raw();
    sample.voltage_mv = angle_sensor_raw_to_mv(sample.raw);
    sample.angle_tenths = angle_sensor_raw_to_tenths(sample.raw);

    return sample;
}
