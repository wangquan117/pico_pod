#ifndef LCD1602_RGB_H
#define LCD1602_RGB_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// SD_UI_PATCH: LCD1602 RGB 模块头文件，统一管理地址、行列数和最小接口。

// SD_UI_PATCH: DFR0464 当前接在 J5，对应 I2C0 的 GP4/GP5。
#define LCD1602_I2C_SDA_PIN 4u
#define LCD1602_I2C_SCL_PIN 5u
#define LCD1602_LCD_ADDR 0x3Eu
#define LCD1602_RGB_ADDR 0x2Du
#define LCD1602_COLUMNS 16u
#define LCD1602_ROWS 2u

bool lcd1602_rgb_init(void);
bool lcd1602_rgb_set_backlight(uint8_t red, uint8_t green, uint8_t blue);
bool lcd1602_rgb_write_line(uint8_t row, const char *text);

#endif
