//参考链接：https://wiki.dfrobot.com/dfr0464/

#include "lcd1602_rgb.h"

#include <string.h>

#include "pico/stdlib.h"
#include "hardware/gpio.h"
#include "hardware/i2c.h"

// SD_UI_PATCH
// 这个模块负责 DFR0464 的 I2C 通讯和 1602 字符显示：
// 1. 初始化 I2C0 GP4/GP5；
// 2. 写字符控制器命令和数据；
// 3. 设置 RGB 背光；
// 4. 对上层暴露“初始化/写一行/设背光”三个最小接口。

// SD_UI_PATCH: 先用 100kHz 做首版，抗线长和上拉差异更稳一些。
//参考链接：https://components.espressif.com/components/pedrominatel/grove_lcd/versions/1.0.0/readme?language=en
#define LCD1602_I2C_PORT i2c0
#define LCD1602_I2C_BAUDRATE 100000u

#define LCD1602_CMD_CLEAR 0x01u
#define LCD1602_CMD_HOME 0x02u
#define LCD1602_CMD_ENTRY_MODE 0x04u
#define LCD1602_CMD_DISPLAY_CTRL 0x08u
#define LCD1602_CMD_FUNCTION_SET 0x20u
#define LCD1602_CMD_SET_DDRAM 0x80u

#define LCD1602_ENTRY_LEFT 0x02u
#define LCD1602_ENTRY_SHIFT_DEC 0x00u
#define LCD1602_DISPLAY_ON 0x04u
#define LCD1602_CURSOR_OFF 0x00u
#define LCD1602_BLINK_OFF 0x00u
#define LCD1602_4BITMODE 0x00u
#define LCD1602_2LINE 0x08u
#define LCD1602_5X8DOTS 0x00u

static bool lcd1602_write_lcd(const uint8_t *data, size_t length)
{
    // SD_UI_PATCH: 写字符控制器地址，处理 DDRAM 命令和字符数据。
    return i2c_write_blocking(LCD1602_I2C_PORT, LCD1602_LCD_ADDR, data, length, false) == (int)length;
}

static bool lcd1602_write_rgb(uint8_t reg, uint8_t value)
{
    const uint8_t buffer[2] = {reg, value};
    // SD_UI_PATCH: 背光芯片和字符控制器地址分离，所以 RGB 走独立 I2C 地址。
    return i2c_write_blocking(LCD1602_I2C_PORT, LCD1602_RGB_ADDR, buffer, sizeof(buffer), false) == (int)sizeof(buffer);
}

static bool lcd1602_send_command(uint8_t command)
{
    //0x80 表示写入命令区 command写入显示数据
    const uint8_t buffer[2] = {0x80u, command};
    return lcd1602_write_lcd(buffer, sizeof(buffer));
}

static bool lcd1602_send_data(const uint8_t *data, size_t length)
{
    uint8_t buffer[LCD1602_COLUMNS + 1u];

    if (length > LCD1602_COLUMNS) {
        length = LCD1602_COLUMNS;
    }

    // SD_UI_PATCH: DFRobot 这类 RGB1602 模块约定 0x40 表示后续字节写入 DDRAM 数据区。
    buffer[0] = 0x40u;
    memcpy(&buffer[1], data, length);
    return lcd1602_write_lcd(buffer, length + 1u);
}

static bool lcd1602_set_cursor(uint8_t column, uint8_t row)
{
    uint8_t address = (uint8_t)(column & 0x0Fu);

    if (row != 0u) {
        address = (uint8_t)(address | 0x40u);
    }

    return lcd1602_send_command((uint8_t)(LCD1602_CMD_SET_DDRAM | address));
}

static bool lcd1602_clear_line(uint8_t row)
{
    static const char blank_line[LCD1602_COLUMNS + 1u] = "                ";
    return lcd1602_rgb_write_line(row, blank_line);
}

bool lcd1602_rgb_set_backlight(uint8_t red, uint8_t green, uint8_t blue)
{
    // SD_UI_PATCH: DFR0464 V2.0 的 RGB 控制地址按 0x2D 处理，RGB 寄存器顺序为
    // 0x01/0x02/0x03。后续如果你实物版本不同，只需要改头文件里的地址定义。
    bool ok = true;
    ok = lcd1602_write_rgb(0x01u, red) && ok;
    ok = lcd1602_write_rgb(0x02u, green) && ok;
    ok = lcd1602_write_rgb(0x03u, blue) && ok;
    return ok;
}

bool lcd1602_rgb_write_line(uint8_t row, const char *text)
{
    char padded[LCD1602_COLUMNS];
    const size_t length = strlen(text) > LCD1602_COLUMNS ? LCD1602_COLUMNS : strlen(text);

    // SD_UI_PATCH: 1602 是定长字符屏，先补空格可以覆盖旧内容，避免短字符串残留。
    memset(padded, ' ', sizeof(padded));
    memcpy(padded, text, length);

    return lcd1602_set_cursor(0u, row) && lcd1602_send_data((const uint8_t *)padded, sizeof(padded));
}

bool lcd1602_rgb_init(void)
{
    bool ok = true;
    //为什么先用 100k：

    // 字符屏带宽需求很低 线长、模块版本、上拉不确定时，100kHz 更稳 没必要一上来冲 400k
    i2c_init(LCD1602_I2C_PORT, LCD1602_I2C_BAUDRATE);
    gpio_set_function(LCD1602_I2C_SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(LCD1602_I2C_SCL_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(LCD1602_I2C_SDA_PIN);
    gpio_pull_up(LCD1602_I2C_SCL_PIN);

    sleep_ms(50);

    // SD_UI_PATCH: 这里沿用 DFRobot RGBLCD1602 的最小初始化序列，先把字符控制器
    //设置字符屏工作模式 拉到稳定的 2 行 5x8 模式，再开显示并配置输入方向。
    //连续发 3 次：这是字符 LCD 很常见的保守初始化手法，上电刚稳定时，控制器状态未必完全可靠连续发几次 Function Set 能把模式锁稳
    ok = lcd1602_send_command((uint8_t)(LCD1602_CMD_FUNCTION_SET | LCD1602_4BITMODE | LCD1602_2LINE | LCD1602_5X8DOTS)) && ok;
    sleep_ms(5);
    ok = lcd1602_send_command((uint8_t)(LCD1602_CMD_FUNCTION_SET | LCD1602_4BITMODE | LCD1602_2LINE | LCD1602_5X8DOTS)) && ok;
    sleep_ms(5);
    ok = lcd1602_send_command((uint8_t)(LCD1602_CMD_FUNCTION_SET | LCD1602_4BITMODE | LCD1602_2LINE | LCD1602_5X8DOTS)) && ok;

    ok = lcd1602_send_command((uint8_t)(LCD1602_CMD_DISPLAY_CTRL | LCD1602_DISPLAY_ON | LCD1602_CURSOR_OFF | LCD1602_BLINK_OFF)) && ok;
    //清屏，清空 DDRAM 显示内容
    ok = lcd1602_send_command(LCD1602_CMD_CLEAR) && ok;
    sleep_ms(2);
    //设置字符屏工作模式 每写一个字符，光标自动右移一个字符
    ok = lcd1602_send_command((uint8_t)(LCD1602_CMD_ENTRY_MODE | LCD1602_ENTRY_LEFT | LCD1602_ENTRY_SHIFT_DEC)) && ok;
    //将光标移动到第一行第一列
    ok = lcd1602_send_command(LCD1602_CMD_HOME) && ok;
    sleep_ms(2);
    
    ok = lcd1602_rgb_set_backlight(0u, 180u, 255u) && ok;
    ok = lcd1602_clear_line(0u) && ok;
    ok = lcd1602_clear_line(1u) && ok;

    return ok;
}
