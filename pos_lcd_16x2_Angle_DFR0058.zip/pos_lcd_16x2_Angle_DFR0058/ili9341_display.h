#ifndef ILI9341_DISPLAY_H
#define ILI9341_DISPLAY_H

#include <stdint.h>

// SD_UI_PATCH: ILI9341 驱动头文件，只暴露上层真正需要的显示接口。

// SD_UI_PATCH: 继续沿用当前工程已经验证过的 ILI9341 接线定义。
#define LCD_PIN_RST 21u
#define LCD_PIN_DC 20u
#define LCD_PIN_CS 17u
#define LCD_PIN_SCK 18u
#define LCD_PIN_MOSI 19u
#define LCD_PIN_BL 22u

#ifndef LCD_ROTATION_DEGREES
#define LCD_ROTATION_DEGREES 90u
#endif

void ili9341_init(void);
void ili9341_fill_screen(uint16_t rgb565);
void ili9341_fill_rect(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint16_t rgb565);
void ili9341_draw_text_5x7(uint16_t x, uint16_t y, const char *text, uint16_t rgb565, uint8_t scale);
uint16_t ili9341_text_width(const char *text, uint8_t scale);
uint16_t ili9341_get_width(void);
uint16_t ili9341_get_height(void);

#endif
