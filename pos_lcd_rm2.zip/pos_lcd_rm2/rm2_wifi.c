#include <stdio.h>

#include "lwip/ip4_addr.h"
#include "lwip/netif.h"
#include "pico/cyw43_arch.h"
#include "pico/stdio_usb.h"
#include "pico/stdlib.h"

#define WIFI_SSID "IAC 2.4G"
#define WIFI_PASSWORD "hello1234"
#define WIFI_AUTH CYW43_AUTH_WPA2_AES_PSK
#define STATUS_PERIOD_MS 2000

static void print_status(void) {
    if (!stdio_usb_connected()) {
        return;
    }

    int link = cyw43_tcpip_link_status(&cyw43_state, CYW43_ITF_STA);
    if (link == CYW43_LINK_UP) {
        cyw43_arch_lwip_begin();
        printf("%s\n", ip4addr_ntoa(netif_ip4_addr(&cyw43_state.netif[CYW43_ITF_STA])));
        cyw43_arch_lwip_end();
        return;
    }

    printf("false\n");
    if (link <= CYW43_LINK_DOWN) {
        cyw43_arch_wifi_connect_async(WIFI_SSID, WIFI_PASSWORD, WIFI_AUTH);
    }
}

int main(void) {
    if (cyw43_arch_init()) {
        while (true) {
            tight_loop_contents();
        }
    }

    cyw43_arch_gpio_put(CYW43_WL_GPIO_LED_PIN, true);
    stdio_init_all();

    cyw43_arch_enable_sta_mode();
    cyw43_arch_wifi_connect_async(WIFI_SSID, WIFI_PASSWORD, WIFI_AUTH);

    absolute_time_t next_status = get_absolute_time();
    while (true) {
        cyw43_arch_poll();
        if (time_reached(next_status)) {
            print_status();
            next_status = make_timeout_time_ms(STATUS_PERIOD_MS);
        }
        cyw43_arch_wait_for_work_until(next_status);
    }
}
