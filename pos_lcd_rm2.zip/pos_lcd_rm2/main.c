#include "pico/stdlib.h"
#include "pico/cyw43_arch.h"

int main(void) {
    stdio_init_all();
    sleep_ms(1000);

    int rc = cyw43_arch_init();
    if (rc != 0) {
        printf("RM2 gSPI init failed: %d\n", rc);
        while (true) {
            tight_loop_contents();
        }
    }

    // RM2 GPIO0 is controlled inside the CYW43439 over gSPI.
    cyw43_arch_gpio_put(0, true);
    printf("RM2 gSPI ready, RM2 GPIO0 = %s\n",
           cyw43_arch_gpio_get(0) ? "HIGH" : "LOW");

    while (true) {
        tight_loop_contents();
    }
}
