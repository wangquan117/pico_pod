/*
 * RP2040 host board connected to a Raspberry Pi Radio Module 2.
 * Same gSPI pin map as Argon_pico (RP2350); only the host MCU differs.
 */

#ifndef _BOARDS_POS_LCD_RM2_H
#define _BOARDS_POS_LCD_RM2_H

#include "boards/pico.h"

pico_board_cmake_set(PICO_PLATFORM, rp2040)
pico_board_cmake_set(PICO_CYW43_SUPPORTED, 1)

#define POS_LCD_RM2

#undef PICO_DEFAULT_LED_PIN

// RM2 gSPI pins. The data input, data output, and interrupt share GPIO16.
#undef CYW43_DEFAULT_PIN_WL_REG_ON
#define CYW43_DEFAULT_PIN_WL_REG_ON 7u

#undef CYW43_DEFAULT_PIN_WL_DATA_OUT
#define CYW43_DEFAULT_PIN_WL_DATA_OUT 19u

#undef CYW43_DEFAULT_PIN_WL_DATA_IN
#define CYW43_DEFAULT_PIN_WL_DATA_IN 19u

#undef CYW43_DEFAULT_PIN_WL_HOST_WAKE
#define CYW43_DEFAULT_PIN_WL_HOST_WAKE 19u

#undef CYW43_DEFAULT_PIN_WL_CLOCK
#define CYW43_DEFAULT_PIN_WL_CLOCK 18u

#undef CYW43_DEFAULT_PIN_WL_CS
#define CYW43_DEFAULT_PIN_WL_CS 17u

// RM2 GPIO0 drives LED2. GPIO1 is wired to AP3441 FB — never drive it.
#undef CYW43_WL_GPIO_COUNT
#define CYW43_WL_GPIO_COUNT 3

#ifndef CYW43_WL_GPIO_LED_PIN
#define CYW43_WL_GPIO_LED_PIN 0
#endif

#endif
